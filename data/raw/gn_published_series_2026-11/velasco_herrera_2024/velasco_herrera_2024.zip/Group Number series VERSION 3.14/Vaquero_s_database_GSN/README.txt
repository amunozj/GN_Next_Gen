


The file GNobservations_JV_V1-12.txt and GNobservations_JV_v1.21.txt include both versions
(v1.12 and v1.21) by J.M. Vaquero, L. Svalgaard, V.M.S. Carrasco, F. Clette, L. Lefèvre, M.C. Gallego, R. Arlt, A.J.P. Aparicio, J.-G. Richard, and R. Howe: 2016, Solar Physics.

Also, the file "Difference_GSN_V1.22_V1.12" illustrates the disparities between the two databases and highlights inconsistencies between the GSN data reported by observers and the corresponding data in each of these databases.∫