


The file GSN_removed.xlsx comprises GSN data that has been excluded from the raw GSN database due to abnormal values.